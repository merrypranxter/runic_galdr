# runic_galdr

> 24 runes. elder futhark. bindrunes and galdr as generative grammar.

A complete Elder Futhark rune system rendered as interactive visual grammar. All 24 runes with phonetic, symbolic, and mystical meanings. Bindrune composition overlays multiple runes for combined magical intent. Galdr visualization maps sound frequencies to rune resonance patterns. Includes runic calendar and divination spreads.

## Live Controls

| Key | Action |
|-----|--------|
| `Space` | Sing galdr for selected rune (visual resonance) |
| `B` | Enter bindrune composition mode |
| `C` | Show runic calendar |
| `D` | Cast rune divination spread |
| `K` | Generate runic knotwork from selection |
| `1–24` | Select specific rune |

## Named Regimes

- **Elder Futhark** — Complete 24-rune set with meanings
- **Bindrune** — Overlay runes for combined intent
- **Galdr** — Sound frequency resonance visualization
- **Runic Calendar** — 24 half-months with rune correspondences
- **Divination** — 3-rune or 5-rune spreads
- **Knotwork** — Interlaced patterns from rune shapes

## The Math

Elder Futhark (24 runes, 3 aettir of 8):
1. Freyr's Aett: ᚠ Fehu, ᚢ Uruz, ᚦ Thurisaz, ᚨ Ansuz, ᚱ Raido, ᚲ Kaunan, ᚷ Gebo, ᚹ Wunjo
2. Hagal's Aett: ᚺ Hagalaz, ᚾ Naudiz, ᛁ Isaz, ᛃ Jera, ᛇ Eihwaz, ᛉ Pertho, ᛊ Algiz, ᛏ Tiwaz
3. Tyr's Aett: ᛒ Berkanan, ᛖ Ehwaz, ᛗ Mannaz, ᛚ Laguz, ᛜ Ingwaz, ᛞ Dagaz, ᛟ Othala

Bindrune composition:
- Select 2–4 runes
- Overlay with shared vertical staves when possible
- Merge intersecting lines
- Add decorative elements

Galdr frequencies (Hz, approximate):
- Each rune mapped to resonant frequency based on phonetic value
- Visualization: concentric wave patterns from rune center

## Acknowledgments

Elder Futhark tradition, Edred Thorsson's *Futhark: A Handbook of Rune Magic*, *The Poetic Edda*.
