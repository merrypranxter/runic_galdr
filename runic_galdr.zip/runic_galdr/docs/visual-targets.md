# Visual Targets: runic_galdr

> TODO: describe desired visual output, color palettes, and animation behavior.
