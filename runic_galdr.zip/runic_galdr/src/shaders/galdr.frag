// TODO: galdr.frag
