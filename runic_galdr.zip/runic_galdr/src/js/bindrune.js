// Rune overlay and merge composition
