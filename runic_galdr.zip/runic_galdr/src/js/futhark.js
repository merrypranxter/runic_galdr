// 24 Elder Futhark rune definitions
