// Rune system renderer and interaction loop
